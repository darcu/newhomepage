<?php get_header(); ?>
<div class="fp_content content" role="main">
	<!-- slider -->
	<div class="fp_slaider slaider">
	<?php //echo do_shortcode("[metaslider id=29]"); ?>
	<ul class="rslides" id="homeslider">
      <li><img src="/test/wordpress/wp-content/uploads/1-1024x640.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/2-1024x640.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/3-1024x640.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/4-1024x640.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/5-1024x640.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/6-1024x640.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/7-1024x640.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/8-1024x640.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/9-1024x640.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/10-1024x640.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/11-1024x640.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/12-1024x639.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/13-1024x640.jpg" alt=""></li>
      <li><img src="/test/wordpress/wp-content/uploads/14-1024x639.jpg" alt=""></li>
    </ul>	
	</div>
	<?php if(have_posts()) : ?>
		<?php while(have_posts()) : the_post(); ?>
			<div class="fp_entry entry">
				<?php the_content(); ?>
			</div>
		<?php endwhile; ?>
    <?php endif; ?>
    <!-- <div id="third">
    	<a href="http://darcu.net/test/wordpress/wp-content/uploads/14-500.jpg">
    		<img class="front_img" alt="14 500" src="http://darcu.net/test/wordpress/wp-content/uploads/14-500-250x156.jpg" width="250" height="156" />
    	</a> 
    	<a href="http://darcu.net/test/wordpress/wp-content/uploads/13-500.jpg">
    		<img class="front_img" alt="13 500" src="http://darcu.net/test/wordpress/wp-content/uploads/13-500-250x156.jpg" width="250" height="156" />
    	</a> 
    	<a href="http://darcu.net/test/wordpress/wp-content/uploads/12-500.jpg">
    		<img class="front_img" alt="12 500" src="http://darcu.net/test/wordpress/wp-content/uploads/12-500-250x156.jpg" width="250" height="156" />
    	</a> 
    	<a href="http://darcu.net/test/wordpress/wp-content/uploads/11-500.jpg">
    		<img class="front_img" alt="11 500" src="http://darcu.net/test/wordpress/wp-content/uploads/11-500-250x156.jpg" width="250" height="156" />
    	</a> 
    	<a href="http://darcu.net/test/wordpress/wp-content/uploads/10-500.jpg">
    		<img class="front_img" alt="10 500" src="http://darcu.net/test/wordpress/wp-content/uploads/10-500-250x156.jpg" width="250" height="156" />
    	</a> 
    	<a href="http://darcu.net/test/wordpress/wp-content/uploads/9-500.jpg">
    		<img class="front_img" alt="9 500" src="http://darcu.net/test/wordpress/wp-content/uploads/9-500-250x156.jpg" width="250" height="156" />
    	</a>
    </div> -->
</div>    
<!-- the footer -->
<?php get_footer(); ?>
<!-- end wrapper -->
</div>


<!-- <?php get_sidebar(); ?>    -->
