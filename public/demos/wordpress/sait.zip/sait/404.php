<?php get_header(); ?>
   <div id="content" class="content clear flex">
     <!-- <h2 class="center">Eroare 404 - Nu e</h2> -->
     <iframe width="480" height="360" src="//www.youtube.com/embed/q0pv6JuH_2k" frameborder="0"></iframe>
   </div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>