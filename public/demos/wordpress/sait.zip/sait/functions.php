<?php

	//Add support for WordPress 3.0's custom menus
	add_action( 'init', 'register_my_menu' );
	 
	//Register area for custom menu
	function register_my_menu() {
	    register_nav_menu( 'header-menu', __( 'Header Menu' ) );
	}

	// Enable post thumbnails
	add_theme_support('post-thumbnails');
	set_post_thumbnail_size(520, 250, true);

	//Some simple code for our widget-enabled sidebar
	if ( function_exists('register_sidebar') )
	    register_sidebar();

	// custom backgrounds
	$args = array(
		'default-color' => '000000',
		'default-image' => get_template_directory_uri() . '/images/aapl19.jpg',
	);
	add_theme_support( 'custom-background' );

	//fixes admin bar positioning
	add_theme_support( 'admin-bar', array( 'callback' => '__return_false') );

	//short post excerpts
	// function excerpt_read_more_link($output) {
	// 	global $post;
	// 	return $output . '<a href="'. get_permalink($post->ID) . '"> Detalii...</a>';
	// }
	// add_filter('the_excerpt', 'excerpt_read_more_link');



	// 210px width images for the grid
	if ( function_exists( 'add_theme_support' ) ) {
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 210 );
	}
	if ( function_exists( 'add_image_size' ) ) {
		add_image_size( 'homepage-thumb', 210, 210, 1 );
		add_image_size( 'page-slide', 900 );
		add_image_size( 'home-slide', 1024 );
	}

	//custom excerpt length
	function custom_excerpt_length( $length ) {
		return 20;
	}
	add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

	//remove [...] from excerpt
	function new_excerpt_more( $more ) {
		return ' ...';
	}
	add_filter('excerpt_more', 'new_excerpt_more');


?>