<?php get_header(); ?>
<div class="pg_content content clearfix" role="main">
	<!-- slider -->
	<div class="pg_slaider slaider">
	<ul class="rslides" id="pageslider">
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/1-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/2-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/3-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/4-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/5-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/6-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/7-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/8-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/9-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/10-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/11-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/12-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/13-900x562.jpg" alt=""></li>
      <li><img class="attachment-home-slide" src="/test/wordpress/wp-content/uploads/14-900x562.jpg" alt=""></li>
    </ul>	
	</div>
	<?php if(have_posts()) : ?>
		<?php while(have_posts()) : the_post(); ?>
			<div class="pg_entry entry ">
				<?php the_content(); ?>
			</div>
		<?php endwhile; ?>
    <?php endif; ?>
</div>
<!-- the footer -->
<?php get_footer(); ?>
<!-- end wrapper -->
</div>


<!-- <?php get_sidebar(); ?>    -->
