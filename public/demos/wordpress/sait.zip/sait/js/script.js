//$(window).load(function() { document.getElementById("hideme").style.display = "none"; });

$(document).ready(function() {

	//width 152px
	var setWidth = function() {
		console.log('x');
		var footerWid = parseInt($('.footer').css('width'));
		var iconsWid = parseInt($('.icons').css('width')) + 14;

		var widToSet = (footerWid - iconsWid) + 'px';
		// console.log(footerWid + ' ' + iconsWid + ' ' + widToSet);
		$('.contact').css('width', widToSet);
	};

	setWidth();

	$(window).resize(function(){
		setWidth();
	});

});