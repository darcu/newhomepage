<?php get_header(); ?>
	<div class="i_content content" role="main">
		<?php if(have_posts()) : ?>
			<div id="boxes">
				<?php query_posts($query_string . "&amp;order=ASC"); ?>
				<?php while(have_posts()) : the_post(); ?>
					<a href="<?php the_permalink(); ?>">
						<div class="box">
							<?php the_post_thumbnail('homepage-thumb'); ?>
							<?php //if ( has_post_thumbnail() ) { the_post_thumbnail( 'homepage-thumb' ); } ?>
							<h3 class="title"><?php the_title(); ?></h3>
							<?php the_excerpt() ?>
						</div>
					</a>
				<?php endwhile; ?>
	        <!-- <div class="navigation">
		        <?php posts_nav_link(); ?>
	        </div> -->
	    <?php endif; ?>
	</div>
	<!-- 			<div id="div3"></div> -->
		<?php get_footer(); ?>
	</div>


<!-- <?php get_sidebar(); ?>    -->
