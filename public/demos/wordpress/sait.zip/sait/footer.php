    <div class="footer">
      <div class="contact ">Date contact</div><div class="icons "><a class="icon_link" id="facebook" href="#" alt="Facebook"></a><a class="icon_link" id="twitter" href="#" alt="Twitter"></a><a class="icon_link" id="skype" href="#" alt="Skype"></a></div>
    </div>
  </div> <!-- end wrapper -->
  <?php wp_footer(); ?>
  <link rel="stylesheet" href="/test/wordpress/wp-content/themes/sait/js/responsiveslides.css">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
  <script src="/test/wordpress/wp-content/themes/sait/js/responsiveslides.min.js"></script>
  <script src="/test/wordpress/wp-content/themes/sait/js/script.js"></script>
  <script>
  // You can also use "$(window).load(function() {"
    $(function () {
      // Slideshow 1
      $("#homeslider").responsiveSlides({
        // nav: true,
        maxwidth: 1024,
        speed: 800
      });
      // Slideshow 2
      $("#pageslider").responsiveSlides({
        //auto: false,
        //pager: true,
        maxwidth: 900,
        speed: 800,
      });

      // // Slideshow 3
      // $("#slider3").responsiveSlides({
      //   manualControls: '#slider3-pager',
      //   maxwidth: 540
      // });

      // // Slideshow 4
      // $("#slider4").responsiveSlides({
      //   auto: false,
      //   pager: false,
      //   nav: true,
      //   speed: 500,
      //   namespace: "callbacks",
      //   before: function () {
      //     $('.events').append("<li>before event fired.</li>");
      //   },
      //   after: function () {
      //     $('.events').append("<li>after event fired.</li>");
      //   }
      // });
    });
  </script>
</body>
</html>